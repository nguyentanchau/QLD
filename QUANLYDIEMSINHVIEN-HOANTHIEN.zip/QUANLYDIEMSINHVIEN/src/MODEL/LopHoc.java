/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

/**
 *
 * @author Anonymous
 */
public class LopHoc {
    private String malop;
    private String tenlop;
        private String makhoa;


    public LopHoc() {
    }

    public LopHoc(String malop, String tenlop, String makhoa) {
        this.malop = malop;
        this.tenlop = tenlop;
        this.makhoa = makhoa;
    }

   

    public String getMalop() {
        return malop;
    }

    public void setMalop(String malop) {
        this.malop = malop;
    }

    public String getTenlop() {
        return tenlop;
    }

    public void setTenlop(String tenlop) {
        this.tenlop = tenlop;
    }



    public String getMakhoa() {
        return makhoa;
    }

    public void setMakhoa(String makhoa) {
        this.makhoa = makhoa;
    }

    
}
