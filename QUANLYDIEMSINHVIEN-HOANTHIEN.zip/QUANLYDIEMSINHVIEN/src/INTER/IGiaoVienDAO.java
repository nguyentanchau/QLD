/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package INTER;

import MODEL.GiaoVien;
import java.util.ArrayList;

/**
 *
 * @author Anonymous
 */
public interface IGiaoVienDAO {
    public ArrayList<GiaoVien> getAll();
    public ArrayList<GiaoVien> findByIDMonHoc(String mamh);
    public GiaoVien addNew(GiaoVien gv);
    public GiaoVien updateByID(GiaoVien gv);
     public ArrayList<GiaoVien> CheckID(String magv);
    
}
